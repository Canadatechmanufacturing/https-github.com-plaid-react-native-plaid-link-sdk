// xcode tries to import this header in the auto-generated swift header
// same as here: https://github.com/rnmapbox/maps/blob/b76c000a237b9757a616982d6c07f6ecfd7d60a9/ios/RNMBX/rnmapbox_maps.h
