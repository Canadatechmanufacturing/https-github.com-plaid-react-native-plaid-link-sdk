// codegen treats UnsafeObject as a special type for just plain object and we need to use it for callbacks 
export type UnsafeObject<T> = T;
