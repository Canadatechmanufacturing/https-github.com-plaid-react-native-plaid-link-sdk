import NativeEmbeddedLinkView from '../fabric/EmbeddedLinkViewNativeComponent';

export default NativeEmbeddedLinkView;
